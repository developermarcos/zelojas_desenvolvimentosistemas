﻿
namespace ControleEstoqueDoZe
{
    partial class FormEstoqueCadastroEdicao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEstoqueCadastroEditarTitulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonEstoqueCadastroEdicaoRemover = new System.Windows.Forms.Button();
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar = new System.Windows.Forms.Button();
            this.textBoxEstoqueCadastroEdicaoMotivo = new System.Windows.Forms.TextBox();
            this.labelEstoqueCadastroEdicaoMotivo = new System.Windows.Forms.Label();
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar = new System.Windows.Forms.Label();
            this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar = new System.Windows.Forms.NumericUpDown();
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual = new System.Windows.Forms.TextBox();
            this.labelEstoqueCadastroEdicaoQuantidadeAtual = new System.Windows.Forms.Label();
            this.textBoxEstoqueCadastroEdicaoID = new System.Windows.Forms.TextBox();
            this.labelEstoqueCadastroEdicaoID = new System.Windows.Forms.Label();
            this.textBoxEstoqueCadastroEdicaoNome = new System.Windows.Forms.TextBox();
            this.labelEstoqueCadastroEdicaoNome = new System.Windows.Forms.Label();
            this.panelEditarExcluirPadrao = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar)).BeginInit();
            this.SuspendLayout();
            // 
            // labelEstoqueCadastroEditarTitulo
            // 
            this.labelEstoqueCadastroEditarTitulo.AutoSize = true;
            this.labelEstoqueCadastroEditarTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEditarTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.labelEstoqueCadastroEditarTitulo.Location = new System.Drawing.Point(37, 27);
            this.labelEstoqueCadastroEditarTitulo.Name = "labelEstoqueCadastroEditarTitulo";
            this.labelEstoqueCadastroEditarTitulo.Size = new System.Drawing.Size(248, 31);
            this.labelEstoqueCadastroEditarTitulo.TabIndex = 4;
            this.labelEstoqueCadastroEditarTitulo.Text = "Cadastro Estoque";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.panel1.Controls.Add(this.buttonEstoqueCadastroEdicaoRemover);
            this.panel1.Controls.Add(this.buttonSalvarEstoqueCadastroEdicaoAdicionar);
            this.panel1.Controls.Add(this.textBoxEstoqueCadastroEdicaoMotivo);
            this.panel1.Controls.Add(this.labelEstoqueCadastroEdicaoMotivo);
            this.panel1.Controls.Add(this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar);
            this.panel1.Controls.Add(this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar);
            this.panel1.Controls.Add(this.textBoxEstoqueCadastroEdicaoQuantidadeAtual);
            this.panel1.Controls.Add(this.labelEstoqueCadastroEdicaoQuantidadeAtual);
            this.panel1.Controls.Add(this.textBoxEstoqueCadastroEdicaoID);
            this.panel1.Controls.Add(this.labelEstoqueCadastroEdicaoID);
            this.panel1.Controls.Add(this.textBoxEstoqueCadastroEdicaoNome);
            this.panel1.Controls.Add(this.labelEstoqueCadastroEdicaoNome);
            this.panel1.Location = new System.Drawing.Point(43, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 293);
            this.panel1.TabIndex = 1;
            // 
            // buttonEstoqueCadastroEdicaoRemover
            // 
            this.buttonEstoqueCadastroEdicaoRemover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(84)))), ((int)(((byte)(84)))));
            this.buttonEstoqueCadastroEdicaoRemover.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEstoqueCadastroEdicaoRemover.ForeColor = System.Drawing.Color.White;
            this.buttonEstoqueCadastroEdicaoRemover.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEstoqueCadastroEdicaoRemover.Location = new System.Drawing.Point(275, 228);
            this.buttonEstoqueCadastroEdicaoRemover.Name = "buttonEstoqueCadastroEdicaoRemover";
            this.buttonEstoqueCadastroEdicaoRemover.Size = new System.Drawing.Size(160, 45);
            this.buttonEstoqueCadastroEdicaoRemover.TabIndex = 7;
            this.buttonEstoqueCadastroEdicaoRemover.Text = "Subtrair";
            this.buttonEstoqueCadastroEdicaoRemover.UseVisualStyleBackColor = false;
            // 
            // buttonSalvarEstoqueCadastroEdicaoAdicionar
            // 
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(84)))), ((int)(((byte)(84)))));
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.ForeColor = System.Drawing.Color.White;
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.Location = new System.Drawing.Point(82, 228);
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.Name = "buttonSalvarEstoqueCadastroEdicaoAdicionar";
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.Size = new System.Drawing.Size(160, 45);
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.TabIndex = 6;
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.Text = "Adicionar";
            this.buttonSalvarEstoqueCadastroEdicaoAdicionar.UseVisualStyleBackColor = false;
            // 
            // textBoxEstoqueCadastroEdicaoMotivo
            // 
            this.textBoxEstoqueCadastroEdicaoMotivo.Location = new System.Drawing.Point(249, 105);
            this.textBoxEstoqueCadastroEdicaoMotivo.Multiline = true;
            this.textBoxEstoqueCadastroEdicaoMotivo.Name = "textBoxEstoqueCadastroEdicaoMotivo";
            this.textBoxEstoqueCadastroEdicaoMotivo.Size = new System.Drawing.Size(229, 77);
            this.textBoxEstoqueCadastroEdicaoMotivo.TabIndex = 5;
            // 
            // labelEstoqueCadastroEdicaoMotivo
            // 
            this.labelEstoqueCadastroEdicaoMotivo.AutoSize = true;
            this.labelEstoqueCadastroEdicaoMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEdicaoMotivo.Location = new System.Drawing.Point(245, 83);
            this.labelEstoqueCadastroEdicaoMotivo.Name = "labelEstoqueCadastroEdicaoMotivo";
            this.labelEstoqueCadastroEdicaoMotivo.Size = new System.Drawing.Size(55, 20);
            this.labelEstoqueCadastroEdicaoMotivo.TabIndex = 26;
            this.labelEstoqueCadastroEdicaoMotivo.Text = "Motivo";
            // 
            // labelEstoqueCadastroEdicaoQuantidadeParaAlterar
            // 
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.AutoSize = true;
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.Location = new System.Drawing.Point(25, 83);
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.Name = "labelEstoqueCadastroEdicaoQuantidadeParaAlterar";
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.Size = new System.Drawing.Size(179, 20);
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.TabIndex = 25;
            this.labelEstoqueCadastroEdicaoQuantidadeParaAlterar.Text = "Quantidade para Alterar";
            // 
            // numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar
            // 
            this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar.Location = new System.Drawing.Point(29, 106);
            this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar.Name = "numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar";
            this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar.Size = new System.Drawing.Size(65, 20);
            this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar.TabIndex = 4;
            // 
            // textBoxEstoqueCadastroEdicaoQuantidadeAtual
            // 
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual.Location = new System.Drawing.Point(356, 40);
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual.Multiline = true;
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual.Name = "textBoxEstoqueCadastroEdicaoQuantidadeAtual";
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual.Size = new System.Drawing.Size(123, 20);
            this.textBoxEstoqueCadastroEdicaoQuantidadeAtual.TabIndex = 3;
            // 
            // labelEstoqueCadastroEdicaoQuantidadeAtual
            // 
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.AutoSize = true;
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.Location = new System.Drawing.Point(352, 18);
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.Name = "labelEstoqueCadastroEdicaoQuantidadeAtual";
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.Size = new System.Drawing.Size(133, 20);
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.TabIndex = 22;
            this.labelEstoqueCadastroEdicaoQuantidadeAtual.Text = "Quantidade Atual";
            // 
            // textBoxEstoqueCadastroEdicaoID
            // 
            this.textBoxEstoqueCadastroEdicaoID.Location = new System.Drawing.Point(29, 40);
            this.textBoxEstoqueCadastroEdicaoID.Multiline = true;
            this.textBoxEstoqueCadastroEdicaoID.Name = "textBoxEstoqueCadastroEdicaoID";
            this.textBoxEstoqueCadastroEdicaoID.Size = new System.Drawing.Size(54, 20);
            this.textBoxEstoqueCadastroEdicaoID.TabIndex = 1;
            this.textBoxEstoqueCadastroEdicaoID.TabStop = false;
            // 
            // labelEstoqueCadastroEdicaoID
            // 
            this.labelEstoqueCadastroEdicaoID.AutoSize = true;
            this.labelEstoqueCadastroEdicaoID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEdicaoID.Location = new System.Drawing.Point(25, 18);
            this.labelEstoqueCadastroEdicaoID.Name = "labelEstoqueCadastroEdicaoID";
            this.labelEstoqueCadastroEdicaoID.Size = new System.Drawing.Size(26, 20);
            this.labelEstoqueCadastroEdicaoID.TabIndex = 20;
            this.labelEstoqueCadastroEdicaoID.Text = "ID";
            // 
            // textBoxEstoqueCadastroEdicaoNome
            // 
            this.textBoxEstoqueCadastroEdicaoNome.Location = new System.Drawing.Point(105, 40);
            this.textBoxEstoqueCadastroEdicaoNome.Multiline = true;
            this.textBoxEstoqueCadastroEdicaoNome.Name = "textBoxEstoqueCadastroEdicaoNome";
            this.textBoxEstoqueCadastroEdicaoNome.Size = new System.Drawing.Size(229, 20);
            this.textBoxEstoqueCadastroEdicaoNome.TabIndex = 2;
            // 
            // labelEstoqueCadastroEdicaoNome
            // 
            this.labelEstoqueCadastroEdicaoNome.AutoSize = true;
            this.labelEstoqueCadastroEdicaoNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstoqueCadastroEdicaoNome.Location = new System.Drawing.Point(101, 18);
            this.labelEstoqueCadastroEdicaoNome.Name = "labelEstoqueCadastroEdicaoNome";
            this.labelEstoqueCadastroEdicaoNome.Size = new System.Drawing.Size(51, 20);
            this.labelEstoqueCadastroEdicaoNome.TabIndex = 0;
            this.labelEstoqueCadastroEdicaoNome.Text = "Nome";
            this.labelEstoqueCadastroEdicaoNome.Click += new System.EventHandler(this.labelFornecedoresCadastroEdicaoRazaoSocial_Click);
            // 
            // panelEditarExcluirPadrao
            // 
            this.panelEditarExcluirPadrao.Location = new System.Drawing.Point(583, 610);
            this.panelEditarExcluirPadrao.Name = "panelEditarExcluirPadrao";
            this.panelEditarExcluirPadrao.Size = new System.Drawing.Size(580, 100);
            this.panelEditarExcluirPadrao.TabIndex = 2;
            // 
            // FormEstoqueCadastroEdicao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.ClientSize = new System.Drawing.Size(1184, 749);
            this.Controls.Add(this.panelEditarExcluirPadrao);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelEstoqueCadastroEditarTitulo);
            this.KeyPreview = true;
            this.Name = "FormEstoqueCadastroEdicao";
            this.Text = "Estoque Cadastro/Edição";
            this.Load += new System.EventHandler(this.FormEstoqueCadastroEdicao_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEstoqueCadastroEditarTitulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxEstoqueCadastroEdicaoNome;
        private System.Windows.Forms.Label labelEstoqueCadastroEdicaoNome;
        private System.Windows.Forms.TextBox textBoxEstoqueCadastroEdicaoID;
        private System.Windows.Forms.Label labelEstoqueCadastroEdicaoID;
        private System.Windows.Forms.Panel panelEditarExcluirPadrao;
        private System.Windows.Forms.TextBox textBoxEstoqueCadastroEdicaoMotivo;
        private System.Windows.Forms.Label labelEstoqueCadastroEdicaoMotivo;
        private System.Windows.Forms.Label labelEstoqueCadastroEdicaoQuantidadeParaAlterar;
        private System.Windows.Forms.NumericUpDown numericUpDownEstoqueCadastroEdicaoQuantidadeAlterar;
        private System.Windows.Forms.TextBox textBoxEstoqueCadastroEdicaoQuantidadeAtual;
        private System.Windows.Forms.Label labelEstoqueCadastroEdicaoQuantidadeAtual;
        private System.Windows.Forms.Button buttonEstoqueCadastroEdicaoRemover;
        private System.Windows.Forms.Button buttonSalvarEstoqueCadastroEdicaoAdicionar;
    }
}
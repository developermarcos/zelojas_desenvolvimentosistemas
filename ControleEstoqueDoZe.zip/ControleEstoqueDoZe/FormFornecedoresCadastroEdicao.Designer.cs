﻿
namespace ControleEstoqueDoZe
{
    partial class FormFornecedoresCadastroEdicao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFornecedorCadastroEdicaoTitulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxFornecedorCadastroEdicaoFantasia = new System.Windows.Forms.TextBox();
            this.labelFornecedorCadastroEdicaoFantasia = new System.Windows.Forms.Label();
            this.maskedTextBoxFornecedorCadEditNome = new System.Windows.Forms.MaskedTextBox();
            this.labelFornecedoresCadastroEdicaoCnpjCpf = new System.Windows.Forms.Label();
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial = new System.Windows.Forms.TextBox();
            this.labelFornecedoresCadastroEdicaoRazaoSocial = new System.Windows.Forms.Label();
            this.panelDadosEnderecoPadrao = new System.Windows.Forms.Panel();
            this.panelEditarExcluirPadrao = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelFornecedorCadastroEdicaoTitulo
            // 
            this.labelFornecedorCadastroEdicaoTitulo.AutoSize = true;
            this.labelFornecedorCadastroEdicaoTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFornecedorCadastroEdicaoTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.labelFornecedorCadastroEdicaoTitulo.Location = new System.Drawing.Point(41, 24);
            this.labelFornecedorCadastroEdicaoTitulo.Name = "labelFornecedorCadastroEdicaoTitulo";
            this.labelFornecedorCadastroEdicaoTitulo.Size = new System.Drawing.Size(321, 31);
            this.labelFornecedorCadastroEdicaoTitulo.TabIndex = 3;
            this.labelFornecedorCadastroEdicaoTitulo.Text = "Cadastro Fornecedores";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.panel1.Controls.Add(this.textBoxFornecedorCadastroEdicaoFantasia);
            this.panel1.Controls.Add(this.labelFornecedorCadastroEdicaoFantasia);
            this.panel1.Controls.Add(this.maskedTextBoxFornecedorCadEditNome);
            this.panel1.Controls.Add(this.labelFornecedoresCadastroEdicaoCnpjCpf);
            this.panel1.Controls.Add(this.textBoxFornecedoresCadastroEdicaoRazaoSocial);
            this.panel1.Controls.Add(this.labelFornecedoresCadastroEdicaoRazaoSocial);
            this.panel1.Location = new System.Drawing.Point(47, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 532);
            this.panel1.TabIndex = 1;
            // 
            // textBoxFornecedorCadastroEdicaoFantasia
            // 
            this.textBoxFornecedorCadastroEdicaoFantasia.Location = new System.Drawing.Point(28, 81);
            this.textBoxFornecedorCadastroEdicaoFantasia.Multiline = true;
            this.textBoxFornecedorCadastroEdicaoFantasia.Name = "textBoxFornecedorCadastroEdicaoFantasia";
            this.textBoxFornecedorCadastroEdicaoFantasia.Size = new System.Drawing.Size(229, 20);
            this.textBoxFornecedorCadastroEdicaoFantasia.TabIndex = 3;
            // 
            // labelFornecedorCadastroEdicaoFantasia
            // 
            this.labelFornecedorCadastroEdicaoFantasia.AutoSize = true;
            this.labelFornecedorCadastroEdicaoFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFornecedorCadastroEdicaoFantasia.Location = new System.Drawing.Point(24, 59);
            this.labelFornecedorCadastroEdicaoFantasia.Name = "labelFornecedorCadastroEdicaoFantasia";
            this.labelFornecedorCadastroEdicaoFantasia.Size = new System.Drawing.Size(71, 20);
            this.labelFornecedorCadastroEdicaoFantasia.TabIndex = 18;
            this.labelFornecedorCadastroEdicaoFantasia.Text = "Fantasia";
            // 
            // maskedTextBoxFornecedorCadEditNome
            // 
            this.maskedTextBoxFornecedorCadEditNome.Location = new System.Drawing.Point(263, 37);
            this.maskedTextBoxFornecedorCadEditNome.Name = "maskedTextBoxFornecedorCadEditNome";
            this.maskedTextBoxFornecedorCadEditNome.Size = new System.Drawing.Size(211, 20);
            this.maskedTextBoxFornecedorCadEditNome.TabIndex = 2;
            // 
            // labelFornecedoresCadastroEdicaoCnpjCpf
            // 
            this.labelFornecedoresCadastroEdicaoCnpjCpf.AutoSize = true;
            this.labelFornecedoresCadastroEdicaoCnpjCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFornecedoresCadastroEdicaoCnpjCpf.Location = new System.Drawing.Point(259, 14);
            this.labelFornecedoresCadastroEdicaoCnpjCpf.Name = "labelFornecedoresCadastroEdicaoCnpjCpf";
            this.labelFornecedoresCadastroEdicaoCnpjCpf.Size = new System.Drawing.Size(92, 20);
            this.labelFornecedoresCadastroEdicaoCnpjCpf.TabIndex = 2;
            this.labelFornecedoresCadastroEdicaoCnpjCpf.Text = "CNPJ / CPF";
            // 
            // textBoxFornecedoresCadastroEdicaoRazaoSocial
            // 
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial.Location = new System.Drawing.Point(28, 36);
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial.Multiline = true;
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial.Name = "textBoxFornecedoresCadastroEdicaoRazaoSocial";
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial.Size = new System.Drawing.Size(229, 20);
            this.textBoxFornecedoresCadastroEdicaoRazaoSocial.TabIndex = 1;
            // 
            // labelFornecedoresCadastroEdicaoRazaoSocial
            // 
            this.labelFornecedoresCadastroEdicaoRazaoSocial.AutoSize = true;
            this.labelFornecedoresCadastroEdicaoRazaoSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFornecedoresCadastroEdicaoRazaoSocial.Location = new System.Drawing.Point(24, 14);
            this.labelFornecedoresCadastroEdicaoRazaoSocial.Name = "labelFornecedoresCadastroEdicaoRazaoSocial";
            this.labelFornecedoresCadastroEdicaoRazaoSocial.Size = new System.Drawing.Size(103, 20);
            this.labelFornecedoresCadastroEdicaoRazaoSocial.TabIndex = 0;
            this.labelFornecedoresCadastroEdicaoRazaoSocial.Text = "Razao Social";
            // 
            // panelDadosEnderecoPadrao
            // 
            this.panelDadosEnderecoPadrao.Location = new System.Drawing.Point(582, 68);
            this.panelDadosEnderecoPadrao.Name = "panelDadosEnderecoPadrao";
            this.panelDadosEnderecoPadrao.Size = new System.Drawing.Size(580, 532);
            this.panelDadosEnderecoPadrao.TabIndex = 2;
            // 
            // panelEditarExcluirPadrao
            // 
            this.panelEditarExcluirPadrao.Location = new System.Drawing.Point(582, 622);
            this.panelEditarExcluirPadrao.Name = "panelEditarExcluirPadrao";
            this.panelEditarExcluirPadrao.Size = new System.Drawing.Size(580, 100);
            this.panelEditarExcluirPadrao.TabIndex = 3;
            // 
            // FormFornecedoresCadastroEdicao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.ClientSize = new System.Drawing.Size(1184, 749);
            this.Controls.Add(this.panelEditarExcluirPadrao);
            this.Controls.Add(this.panelDadosEnderecoPadrao);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelFornecedorCadastroEdicaoTitulo);
            this.KeyPreview = true;
            this.Name = "FormFornecedoresCadastroEdicao";
            this.Text = "Fornecedores Cadastro/Edição";
            this.Load += new System.EventHandler(this.FormFornecedoresCadastroEdicao_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelFornecedorCadastroEdicaoTitulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxFornecedorCadastroEdicaoFantasia;
        private System.Windows.Forms.Label labelFornecedorCadastroEdicaoFantasia;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxFornecedorCadEditNome;
        private System.Windows.Forms.Label labelFornecedoresCadastroEdicaoCnpjCpf;
        private System.Windows.Forms.TextBox textBoxFornecedoresCadastroEdicaoRazaoSocial;
        private System.Windows.Forms.Label labelFornecedoresCadastroEdicaoRazaoSocial;
        private System.Windows.Forms.Panel panelDadosEnderecoPadrao;
        private System.Windows.Forms.Panel panelEditarExcluirPadrao;
    }
}
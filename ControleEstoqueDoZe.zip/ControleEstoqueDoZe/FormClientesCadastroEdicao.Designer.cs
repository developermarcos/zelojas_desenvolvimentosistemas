﻿
namespace ControleEstoqueDoZe
{
    partial class FormClientesCadastroEdicao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelClientesCadastroEdicaoDataNascimento = new System.Windows.Forms.Label();
            this.dateTimePickerClientesCadastroEdicaoDataNascimento = new System.Windows.Forms.DateTimePicker();
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial = new System.Windows.Forms.TextBox();
            this.labelClientesCadastroEdicaoRazaoSocial = new System.Windows.Forms.Label();
            this.maskedTextBoxEmpresaCadEditNome = new System.Windows.Forms.MaskedTextBox();
            this.labelClientesCadastroEdicaoCpfCnpj = new System.Windows.Forms.Label();
            this.textBoxClientesCadastroEdicaoNome = new System.Windows.Forms.TextBox();
            this.labelClientesCadastroEdicaoNome = new System.Windows.Forms.Label();
            this.labelClientesCadastroEditarTitulo = new System.Windows.Forms.Label();
            this.panelDadosEnderecoPadrao = new System.Windows.Forms.Panel();
            this.panelEditarExcluirPadrao = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.panel1.Controls.Add(this.labelClientesCadastroEdicaoDataNascimento);
            this.panel1.Controls.Add(this.dateTimePickerClientesCadastroEdicaoDataNascimento);
            this.panel1.Controls.Add(this.textBoxClientesCadastroEdicaoNomeRazaoSocial);
            this.panel1.Controls.Add(this.labelClientesCadastroEdicaoRazaoSocial);
            this.panel1.Controls.Add(this.maskedTextBoxEmpresaCadEditNome);
            this.panel1.Controls.Add(this.labelClientesCadastroEdicaoCpfCnpj);
            this.panel1.Controls.Add(this.textBoxClientesCadastroEdicaoNome);
            this.panel1.Controls.Add(this.labelClientesCadastroEdicaoNome);
            this.panel1.Location = new System.Drawing.Point(34, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 532);
            this.panel1.TabIndex = 1;
            // 
            // labelClientesCadastroEdicaoDataNascimento
            // 
            this.labelClientesCadastroEdicaoDataNascimento.AutoSize = true;
            this.labelClientesCadastroEdicaoDataNascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClientesCadastroEdicaoDataNascimento.Location = new System.Drawing.Point(260, 60);
            this.labelClientesCadastroEdicaoDataNascimento.Name = "labelClientesCadastroEdicaoDataNascimento";
            this.labelClientesCadastroEdicaoDataNascimento.Size = new System.Drawing.Size(132, 20);
            this.labelClientesCadastroEdicaoDataNascimento.TabIndex = 21;
            this.labelClientesCadastroEdicaoDataNascimento.Text = "Data Nascimento";
            // 
            // dateTimePickerClientesCadastroEdicaoDataNascimento
            // 
            this.dateTimePickerClientesCadastroEdicaoDataNascimento.Location = new System.Drawing.Point(264, 80);
            this.dateTimePickerClientesCadastroEdicaoDataNascimento.Name = "dateTimePickerClientesCadastroEdicaoDataNascimento";
            this.dateTimePickerClientesCadastroEdicaoDataNascimento.Size = new System.Drawing.Size(222, 20);
            this.dateTimePickerClientesCadastroEdicaoDataNascimento.TabIndex = 4;
            this.dateTimePickerClientesCadastroEdicaoDataNascimento.Value = new System.DateTime(2021, 3, 28, 0, 0, 0, 0);
            // 
            // textBoxClientesCadastroEdicaoNomeRazaoSocial
            // 
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial.Location = new System.Drawing.Point(28, 80);
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial.Multiline = true;
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial.Name = "textBoxClientesCadastroEdicaoNomeRazaoSocial";
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial.Size = new System.Drawing.Size(229, 20);
            this.textBoxClientesCadastroEdicaoNomeRazaoSocial.TabIndex = 3;
            // 
            // labelClientesCadastroEdicaoRazaoSocial
            // 
            this.labelClientesCadastroEdicaoRazaoSocial.AutoSize = true;
            this.labelClientesCadastroEdicaoRazaoSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClientesCadastroEdicaoRazaoSocial.Location = new System.Drawing.Point(24, 58);
            this.labelClientesCadastroEdicaoRazaoSocial.Name = "labelClientesCadastroEdicaoRazaoSocial";
            this.labelClientesCadastroEdicaoRazaoSocial.Size = new System.Drawing.Size(103, 20);
            this.labelClientesCadastroEdicaoRazaoSocial.TabIndex = 18;
            this.labelClientesCadastroEdicaoRazaoSocial.Text = "Razao Social";
            // 
            // maskedTextBoxEmpresaCadEditNome
            // 
            this.maskedTextBoxEmpresaCadEditNome.Location = new System.Drawing.Point(263, 37);
            this.maskedTextBoxEmpresaCadEditNome.Name = "maskedTextBoxEmpresaCadEditNome";
            this.maskedTextBoxEmpresaCadEditNome.Size = new System.Drawing.Size(211, 20);
            this.maskedTextBoxEmpresaCadEditNome.TabIndex = 2;
            this.maskedTextBoxEmpresaCadEditNome.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBoxEmpresaCadEditNome_MaskInputRejected);
            // 
            // labelClientesCadastroEdicaoCpfCnpj
            // 
            this.labelClientesCadastroEdicaoCpfCnpj.AutoSize = true;
            this.labelClientesCadastroEdicaoCpfCnpj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClientesCadastroEdicaoCpfCnpj.Location = new System.Drawing.Point(259, 14);
            this.labelClientesCadastroEdicaoCpfCnpj.Name = "labelClientesCadastroEdicaoCpfCnpj";
            this.labelClientesCadastroEdicaoCpfCnpj.Size = new System.Drawing.Size(92, 20);
            this.labelClientesCadastroEdicaoCpfCnpj.TabIndex = 2;
            this.labelClientesCadastroEdicaoCpfCnpj.Text = "CNPJ / CPF";
            // 
            // textBoxClientesCadastroEdicaoNome
            // 
            this.textBoxClientesCadastroEdicaoNome.BackColor = System.Drawing.SystemColors.Window;
            this.textBoxClientesCadastroEdicaoNome.Location = new System.Drawing.Point(28, 36);
            this.textBoxClientesCadastroEdicaoNome.Multiline = true;
            this.textBoxClientesCadastroEdicaoNome.Name = "textBoxClientesCadastroEdicaoNome";
            this.textBoxClientesCadastroEdicaoNome.Size = new System.Drawing.Size(229, 20);
            this.textBoxClientesCadastroEdicaoNome.TabIndex = 1;
            // 
            // labelClientesCadastroEdicaoNome
            // 
            this.labelClientesCadastroEdicaoNome.AutoSize = true;
            this.labelClientesCadastroEdicaoNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClientesCadastroEdicaoNome.Location = new System.Drawing.Point(24, 14);
            this.labelClientesCadastroEdicaoNome.Name = "labelClientesCadastroEdicaoNome";
            this.labelClientesCadastroEdicaoNome.Size = new System.Drawing.Size(51, 20);
            this.labelClientesCadastroEdicaoNome.TabIndex = 0;
            this.labelClientesCadastroEdicaoNome.Text = "Nome";
            // 
            // labelClientesCadastroEditarTitulo
            // 
            this.labelClientesCadastroEditarTitulo.AutoSize = true;
            this.labelClientesCadastroEditarTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClientesCadastroEditarTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.labelClientesCadastroEditarTitulo.Location = new System.Drawing.Point(28, 20);
            this.labelClientesCadastroEditarTitulo.Name = "labelClientesCadastroEditarTitulo";
            this.labelClientesCadastroEditarTitulo.Size = new System.Drawing.Size(248, 31);
            this.labelClientesCadastroEditarTitulo.TabIndex = 6;
            this.labelClientesCadastroEditarTitulo.Text = "Cadastro Clientes";
            // 
            // panelDadosEnderecoPadrao
            // 
            this.panelDadosEnderecoPadrao.Location = new System.Drawing.Point(575, 73);
            this.panelDadosEnderecoPadrao.Name = "panelDadosEnderecoPadrao";
            this.panelDadosEnderecoPadrao.Size = new System.Drawing.Size(580, 532);
            this.panelDadosEnderecoPadrao.TabIndex = 2;
            // 
            // panelEditarExcluirPadrao
            // 
            this.panelEditarExcluirPadrao.Location = new System.Drawing.Point(575, 621);
            this.panelEditarExcluirPadrao.Name = "panelEditarExcluirPadrao";
            this.panelEditarExcluirPadrao.Size = new System.Drawing.Size(580, 100);
            this.panelEditarExcluirPadrao.TabIndex = 3;
            // 
            // FormClientesCadastroEdicao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.ClientSize = new System.Drawing.Size(1184, 749);
            this.Controls.Add(this.panelEditarExcluirPadrao);
            this.Controls.Add(this.panelDadosEnderecoPadrao);
            this.Controls.Add(this.labelClientesCadastroEditarTitulo);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.Name = "FormClientesCadastroEdicao";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormClientesCadastroEdicao_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelClientesCadastroEdicaoDataNascimento;
        private System.Windows.Forms.DateTimePicker dateTimePickerClientesCadastroEdicaoDataNascimento;
        private System.Windows.Forms.TextBox textBoxClientesCadastroEdicaoNomeRazaoSocial;
        private System.Windows.Forms.Label labelClientesCadastroEdicaoRazaoSocial;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEmpresaCadEditNome;
        private System.Windows.Forms.Label labelClientesCadastroEdicaoCpfCnpj;
        private System.Windows.Forms.TextBox textBoxClientesCadastroEdicaoNome;
        private System.Windows.Forms.Label labelClientesCadastroEdicaoNome;
        private System.Windows.Forms.Label labelClientesCadastroEditarTitulo;
        private System.Windows.Forms.Panel panelDadosEnderecoPadrao;
        private System.Windows.Forms.Panel panelEditarExcluirPadrao;
    }
}
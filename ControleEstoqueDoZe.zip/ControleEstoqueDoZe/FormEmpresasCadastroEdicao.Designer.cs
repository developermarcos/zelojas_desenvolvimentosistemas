﻿
namespace ControleEstoqueDoZe
{
    partial class FormEmpresasCadastroEdicao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEmpresaCadastroEditarTitulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelEmpresaCadastroEdicaoGerente = new System.Windows.Forms.Label();
            this.comboBoxEmpresaCadastroEdicaoGerente = new System.Windows.Forms.ComboBox();
            this.textBoxEmpresaCadastroEdicaoFantasia = new System.Windows.Forms.TextBox();
            this.labelEmpresaCadastroEdicaoFantasia = new System.Windows.Forms.Label();
            this.maskedTextBoxEmpresaCadEditNome = new System.Windows.Forms.MaskedTextBox();
            this.groupBoxTipoEmpresaCadEditTipo = new System.Windows.Forms.GroupBox();
            this.radioButtonEmpresaCadEditMatriz = new System.Windows.Forms.RadioButton();
            this.radioButtonEmpresaCadEditFilial = new System.Windows.Forms.RadioButton();
            this.labelEmpresaCadastroEdicaoCnpjCpf = new System.Windows.Forms.Label();
            this.textBoxEmpresaCadastroEdicaoRazaoSocial = new System.Windows.Forms.TextBox();
            this.labelEmpresaCadastroEdicaoRazaoSocial = new System.Windows.Forms.Label();
            this.panelDadosEnderecoPadrao = new System.Windows.Forms.Panel();
            this.panelEditarExcluirPadrao = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBoxTipoEmpresaCadEditTipo.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelEmpresaCadastroEditarTitulo
            // 
            this.labelEmpresaCadastroEditarTitulo.AutoSize = true;
            this.labelEmpresaCadastroEditarTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmpresaCadastroEditarTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.labelEmpresaCadastroEditarTitulo.Location = new System.Drawing.Point(30, 9);
            this.labelEmpresaCadastroEditarTitulo.Name = "labelEmpresaCadastroEditarTitulo";
            this.labelEmpresaCadastroEditarTitulo.Size = new System.Drawing.Size(256, 31);
            this.labelEmpresaCadastroEditarTitulo.TabIndex = 3;
            this.labelEmpresaCadastroEditarTitulo.Text = "Cadastro Empresa";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.panel1.Controls.Add(this.labelEmpresaCadastroEdicaoGerente);
            this.panel1.Controls.Add(this.comboBoxEmpresaCadastroEdicaoGerente);
            this.panel1.Controls.Add(this.textBoxEmpresaCadastroEdicaoFantasia);
            this.panel1.Controls.Add(this.labelEmpresaCadastroEdicaoFantasia);
            this.panel1.Controls.Add(this.maskedTextBoxEmpresaCadEditNome);
            this.panel1.Controls.Add(this.groupBoxTipoEmpresaCadEditTipo);
            this.panel1.Controls.Add(this.labelEmpresaCadastroEdicaoCnpjCpf);
            this.panel1.Controls.Add(this.textBoxEmpresaCadastroEdicaoRazaoSocial);
            this.panel1.Controls.Add(this.labelEmpresaCadastroEdicaoRazaoSocial);
            this.panel1.Location = new System.Drawing.Point(36, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 532);
            this.panel1.TabIndex = 1;
            // 
            // labelEmpresaCadastroEdicaoGerente
            // 
            this.labelEmpresaCadastroEdicaoGerente.AutoSize = true;
            this.labelEmpresaCadastroEdicaoGerente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmpresaCadastroEdicaoGerente.Location = new System.Drawing.Point(259, 120);
            this.labelEmpresaCadastroEdicaoGerente.Name = "labelEmpresaCadastroEdicaoGerente";
            this.labelEmpresaCadastroEdicaoGerente.Size = new System.Drawing.Size(68, 20);
            this.labelEmpresaCadastroEdicaoGerente.TabIndex = 21;
            this.labelEmpresaCadastroEdicaoGerente.Text = "Gerente";
            // 
            // comboBoxEmpresaCadastroEdicaoGerente
            // 
            this.comboBoxEmpresaCadastroEdicaoGerente.FormattingEnabled = true;
            this.comboBoxEmpresaCadastroEdicaoGerente.Location = new System.Drawing.Point(263, 142);
            this.comboBoxEmpresaCadastroEdicaoGerente.Name = "comboBoxEmpresaCadastroEdicaoGerente";
            this.comboBoxEmpresaCadastroEdicaoGerente.Size = new System.Drawing.Size(229, 21);
            this.comboBoxEmpresaCadastroEdicaoGerente.TabIndex = 7;
            // 
            // textBoxEmpresaCadastroEdicaoFantasia
            // 
            this.textBoxEmpresaCadastroEdicaoFantasia.Location = new System.Drawing.Point(28, 142);
            this.textBoxEmpresaCadastroEdicaoFantasia.Multiline = true;
            this.textBoxEmpresaCadastroEdicaoFantasia.Name = "textBoxEmpresaCadastroEdicaoFantasia";
            this.textBoxEmpresaCadastroEdicaoFantasia.Size = new System.Drawing.Size(229, 20);
            this.textBoxEmpresaCadastroEdicaoFantasia.TabIndex = 6;
            // 
            // labelEmpresaCadastroEdicaoFantasia
            // 
            this.labelEmpresaCadastroEdicaoFantasia.AutoSize = true;
            this.labelEmpresaCadastroEdicaoFantasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmpresaCadastroEdicaoFantasia.Location = new System.Drawing.Point(24, 120);
            this.labelEmpresaCadastroEdicaoFantasia.Name = "labelEmpresaCadastroEdicaoFantasia";
            this.labelEmpresaCadastroEdicaoFantasia.Size = new System.Drawing.Size(71, 20);
            this.labelEmpresaCadastroEdicaoFantasia.TabIndex = 18;
            this.labelEmpresaCadastroEdicaoFantasia.Text = "Fantasia";
            // 
            // maskedTextBoxEmpresaCadEditNome
            // 
            this.maskedTextBoxEmpresaCadEditNome.Location = new System.Drawing.Point(263, 37);
            this.maskedTextBoxEmpresaCadEditNome.Name = "maskedTextBoxEmpresaCadEditNome";
            this.maskedTextBoxEmpresaCadEditNome.Size = new System.Drawing.Size(211, 20);
            this.maskedTextBoxEmpresaCadEditNome.TabIndex = 2;
            // 
            // groupBoxTipoEmpresaCadEditTipo
            // 
            this.groupBoxTipoEmpresaCadEditTipo.Controls.Add(this.radioButtonEmpresaCadEditMatriz);
            this.groupBoxTipoEmpresaCadEditTipo.Controls.Add(this.radioButtonEmpresaCadEditFilial);
            this.groupBoxTipoEmpresaCadEditTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxTipoEmpresaCadEditTipo.Location = new System.Drawing.Point(28, 63);
            this.groupBoxTipoEmpresaCadEditTipo.Name = "groupBoxTipoEmpresaCadEditTipo";
            this.groupBoxTipoEmpresaCadEditTipo.Size = new System.Drawing.Size(411, 54);
            this.groupBoxTipoEmpresaCadEditTipo.TabIndex = 3;
            this.groupBoxTipoEmpresaCadEditTipo.TabStop = false;
            this.groupBoxTipoEmpresaCadEditTipo.Text = "Tipo";
            // 
            // radioButtonEmpresaCadEditMatriz
            // 
            this.radioButtonEmpresaCadEditMatriz.AutoSize = true;
            this.radioButtonEmpresaCadEditMatriz.Location = new System.Drawing.Point(20, 25);
            this.radioButtonEmpresaCadEditMatriz.Name = "radioButtonEmpresaCadEditMatriz";
            this.radioButtonEmpresaCadEditMatriz.Size = new System.Drawing.Size(70, 24);
            this.radioButtonEmpresaCadEditMatriz.TabIndex = 4;
            this.radioButtonEmpresaCadEditMatriz.TabStop = true;
            this.radioButtonEmpresaCadEditMatriz.Text = "Matriz";
            this.radioButtonEmpresaCadEditMatriz.UseVisualStyleBackColor = true;
            // 
            // radioButtonEmpresaCadEditFilial
            // 
            this.radioButtonEmpresaCadEditFilial.AutoSize = true;
            this.radioButtonEmpresaCadEditFilial.Location = new System.Drawing.Point(112, 25);
            this.radioButtonEmpresaCadEditFilial.Name = "radioButtonEmpresaCadEditFilial";
            this.radioButtonEmpresaCadEditFilial.Size = new System.Drawing.Size(58, 24);
            this.radioButtonEmpresaCadEditFilial.TabIndex = 5;
            this.radioButtonEmpresaCadEditFilial.TabStop = true;
            this.radioButtonEmpresaCadEditFilial.Text = "Filial";
            this.radioButtonEmpresaCadEditFilial.UseVisualStyleBackColor = true;
            // 
            // labelEmpresaCadastroEdicaoCnpjCpf
            // 
            this.labelEmpresaCadastroEdicaoCnpjCpf.AutoSize = true;
            this.labelEmpresaCadastroEdicaoCnpjCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmpresaCadastroEdicaoCnpjCpf.Location = new System.Drawing.Point(259, 14);
            this.labelEmpresaCadastroEdicaoCnpjCpf.Name = "labelEmpresaCadastroEdicaoCnpjCpf";
            this.labelEmpresaCadastroEdicaoCnpjCpf.Size = new System.Drawing.Size(92, 20);
            this.labelEmpresaCadastroEdicaoCnpjCpf.TabIndex = 2;
            this.labelEmpresaCadastroEdicaoCnpjCpf.Text = "CNPJ / CPF";
            // 
            // textBoxEmpresaCadastroEdicaoRazaoSocial
            // 
            this.textBoxEmpresaCadastroEdicaoRazaoSocial.Location = new System.Drawing.Point(28, 36);
            this.textBoxEmpresaCadastroEdicaoRazaoSocial.Multiline = true;
            this.textBoxEmpresaCadastroEdicaoRazaoSocial.Name = "textBoxEmpresaCadastroEdicaoRazaoSocial";
            this.textBoxEmpresaCadastroEdicaoRazaoSocial.Size = new System.Drawing.Size(229, 20);
            this.textBoxEmpresaCadastroEdicaoRazaoSocial.TabIndex = 1;
            // 
            // labelEmpresaCadastroEdicaoRazaoSocial
            // 
            this.labelEmpresaCadastroEdicaoRazaoSocial.AutoSize = true;
            this.labelEmpresaCadastroEdicaoRazaoSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmpresaCadastroEdicaoRazaoSocial.Location = new System.Drawing.Point(24, 14);
            this.labelEmpresaCadastroEdicaoRazaoSocial.Name = "labelEmpresaCadastroEdicaoRazaoSocial";
            this.labelEmpresaCadastroEdicaoRazaoSocial.Size = new System.Drawing.Size(103, 20);
            this.labelEmpresaCadastroEdicaoRazaoSocial.TabIndex = 0;
            this.labelEmpresaCadastroEdicaoRazaoSocial.Text = "Razao Social";
            // 
            // panelDadosEnderecoPadrao
            // 
            this.panelDadosEnderecoPadrao.Location = new System.Drawing.Point(577, 60);
            this.panelDadosEnderecoPadrao.Name = "panelDadosEnderecoPadrao";
            this.panelDadosEnderecoPadrao.Size = new System.Drawing.Size(580, 532);
            this.panelDadosEnderecoPadrao.TabIndex = 2;
            // 
            // panelEditarExcluirPadrao
            // 
            this.panelEditarExcluirPadrao.Location = new System.Drawing.Point(577, 598);
            this.panelEditarExcluirPadrao.Name = "panelEditarExcluirPadrao";
            this.panelEditarExcluirPadrao.Size = new System.Drawing.Size(580, 100);
            this.panelEditarExcluirPadrao.TabIndex = 3;
            // 
            // FormEmpresasCadastroEdicao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.ClientSize = new System.Drawing.Size(1184, 749);
            this.Controls.Add(this.panelEditarExcluirPadrao);
            this.Controls.Add(this.panelDadosEnderecoPadrao);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelEmpresaCadastroEditarTitulo);
            this.KeyPreview = true;
            this.Name = "FormEmpresasCadastroEdicao";
            this.Text = "Cadastro Empresa";
            this.Load += new System.EventHandler(this.FormEmpresasCadastroEdicao_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBoxTipoEmpresaCadEditTipo.ResumeLayout(false);
            this.groupBoxTipoEmpresaCadEditTipo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmpresaCadastroEditarTitulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelEmpresaCadastroEdicaoGerente;
        private System.Windows.Forms.ComboBox comboBoxEmpresaCadastroEdicaoGerente;
        private System.Windows.Forms.TextBox textBoxEmpresaCadastroEdicaoFantasia;
        private System.Windows.Forms.Label labelEmpresaCadastroEdicaoFantasia;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEmpresaCadEditNome;
        private System.Windows.Forms.GroupBox groupBoxTipoEmpresaCadEditTipo;
        private System.Windows.Forms.RadioButton radioButtonEmpresaCadEditMatriz;
        private System.Windows.Forms.RadioButton radioButtonEmpresaCadEditFilial;
        private System.Windows.Forms.Label labelEmpresaCadastroEdicaoCnpjCpf;
        private System.Windows.Forms.TextBox textBoxEmpresaCadastroEdicaoRazaoSocial;
        private System.Windows.Forms.Label labelEmpresaCadastroEdicaoRazaoSocial;
        private System.Windows.Forms.Panel panelDadosEnderecoPadrao;
        private System.Windows.Forms.Panel panelEditarExcluirPadrao;
    }
}